# v1.0.2

- fix country code in plugin editor

# v1.0.1

- update peer dependencies

# v1.0.0

- search nominatim
